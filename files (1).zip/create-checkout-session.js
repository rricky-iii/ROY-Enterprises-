// netlify/functions/create-checkout-session.js
//
// The browser sends us item IDs and quantities ONLY — never prices.
// We look up the real price here, server-side, from PRODUCTS below.
// This is the #1 security rule of any checkout: never trust a price
// that came from the client. Someone could edit it in dev tools.

const Stripe = require('stripe');
const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

// Keep this list in sync with the prices shown in index.html.
// In a bigger shop this would live in a database instead of code.
const PRODUCTS = {
  'silver-rod-45':   { name: '45% Silver Brazing Rod (10-pack)',      cents: 4200 },
  'silver-rod-56':   { name: '56% Silver Brazing Rod (10-pack)',      cents: 5800 },
  'brass-rod-rb':    { name: 'RBCuZn-A Brass Brazing Rod (10-pack)',  cents: 2600 },
  'flux-paste-8oz':  { name: 'Brazing Flux Paste, 8oz',               cents: 1400 },
  'flux-powder-1lb': { name: 'Brazing Flux Powder, 1lb',              cents: 1100 },
  'tip-cleaner-set': { name: 'Torch Tip Cleaner Set',                 cents: 1200 },
};

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const { items } = JSON.parse(event.body); // [{ id, qty }, ...]

    if (!Array.isArray(items) || items.length === 0) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Cart is empty.' }) };
    }

    const line_items = items.map(({ id, qty }) => {
      const product = PRODUCTS[id];
      if (!product) throw new Error(`Unknown product id: ${id}`);
      const quantity = Math.max(1, Math.min(99, parseInt(qty, 10) || 1));
      return {
        price_data: {
          currency: 'usd',
          product_data: { name: product.name },
          unit_amount: product.cents,
        },
        quantity,
      };
    });

    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items,
      success_url: `${process.env.SITE_URL}/success.html?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.SITE_URL}/index.html`,
      shipping_address_collection: { allowed_countries: ['US', 'CA'] },
    });

    return { statusCode: 200, body: JSON.stringify({ url: session.url }) };
  } catch (err) {
    console.error('create-checkout-session error:', err);
    return { statusCode: 400, body: JSON.stringify({ error: err.message }) };
  }
};
