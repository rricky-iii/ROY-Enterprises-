// netlify/functions/submit-job-request.js
//
// Custom brazing jobs don't have a fixed price, so there's no Stripe
// checkout here at all — this just validates the form and emails you
// the details so you can quote it and follow up directly.

const { Resend } = require('resend');
const resend = new Resend(process.env.RESEND_API_KEY);

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const { name, contact, jobType, description, deadline } = JSON.parse(event.body);

    if (!name || !contact || !description) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Name, contact info, and a job description are required.' }),
      };
    }

    await resend.emails.send({
      from: process.env.NOTIFY_FROM_EMAIL,
      to: process.env.NOTIFY_TO_EMAIL,
      subject: `New custom job request — ${name}`,
      html: `
        <h2>New custom job request</h2>
        <p><strong>Name:</strong> ${name}</p>
        <p><strong>Contact:</strong> ${contact}</p>
        <p><strong>Job type:</strong> ${jobType || 'not specified'}</p>
        <p><strong>Needed by:</strong> ${deadline || 'not specified'}</p>
        <p><strong>Description:</strong><br>${description.replace(/\n/g, '<br>')}</p>
      `,
    });

    return { statusCode: 200, body: JSON.stringify({ ok: true }) };
  } catch (err) {
    console.error('submit-job-request error:', err);
    return { statusCode: 500, body: JSON.stringify({ error: 'Something went wrong. Please try again.' }) };
  }
};
