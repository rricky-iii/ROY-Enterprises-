// netlify/functions/stripe-webhook.js
//
// Stripe calls THIS function directly, server-to-server, the moment a
// payment succeeds — completely independent of whether the customer's
// browser makes it back to your success page. This is what makes order
// notification reliable: a closed tab or dead wifi can't cause a missed order.
//
// Signature verification (stripe.webhooks.constructEvent) proves the
// request really came from Stripe and wasn't spoofed by someone hitting
// this URL directly to fake a paid order.

const Stripe = require('stripe');
const { Resend } = require('resend');

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);
const resend = new Resend(process.env.RESEND_API_KEY);

exports.handler = async (event) => {
  const sig = event.headers['stripe-signature'];
  let stripeEvent;

  try {
    stripeEvent = stripe.webhooks.constructEvent(
      event.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return { statusCode: 400, body: `Webhook Error: ${err.message}` };
  }

  if (stripeEvent.type === 'checkout.session.completed') {
    const session = stripeEvent.data.object;

    // Pull full line items — the session object alone doesn't include them.
    const lineItems = await stripe.checkout.sessions.listLineItems(session.id, {
      limit: 100,
    });

    const itemsHtml = lineItems.data
      .map(li => `<li>${li.quantity} × ${li.description} — $${(li.amount_total / 100).toFixed(2)}</li>`)
      .join('');

    const shipping = session.shipping_details;
    const shippingHtml = shipping
      ? `<p><strong>Ship to:</strong> ${shipping.name}<br>
         ${shipping.address.line1}${shipping.address.line2 ? ', ' + shipping.address.line2 : ''}<br>
         ${shipping.address.city}, ${shipping.address.state} ${shipping.address.postal_code}</p>`
      : '';

    try {
      await resend.emails.send({
        from: process.env.NOTIFY_FROM_EMAIL,   // e.g. 'orders@yourdomain.com' (verified in Resend)
        to: process.env.NOTIFY_TO_EMAIL,       // your inbox
        subject: `New order — $${(session.amount_total / 100).toFixed(2)}`,
        html: `
          <h2>New paid order</h2>
          <p><strong>Customer:</strong> ${session.customer_details?.email || 'unknown'}</p>
          <ul>${itemsHtml}</ul>
          <p><strong>Total:</strong> $${(session.amount_total / 100).toFixed(2)}</p>
          ${shippingHtml}
          <p><em>Stripe session: ${session.id}</em></p>
        `,
      });
    } catch (err) {
      // Log but still return 200 — we don't want Stripe to keep retrying
      // just because our email provider had a hiccup. Consider adding
      // a fallback (e.g. write to a database) if email delivery matters
      // as much as the payment itself.
      console.error('Email notification failed:', err);
    }
  }

  return { statusCode: 200, body: JSON.stringify({ received: true }) };
};
